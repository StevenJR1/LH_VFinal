﻿using System.Data;
using System.Data.SqlClient;

namespace Capa3

{
    public class Conexionsql
    {
        static string conexionstring = "server = LAPTOP-KSAPRO4E; database = Ususario; integrated security = true";
        SqlConnection con = new SqlConnection(conexionstring);

        public int consultalogin(string Usuario, string Contraseña)
        {
            int count;
            con.Open();
            string Query = "Select Count(*) From Tabla_Usuario where Usuario ='"+Usuario+"'and contraseña ='"+Contraseña+"'";
            SqlCommand cmd = new SqlCommand(Query, con);
            count = Convert.ToInt32(cmd.ExecuteScalar());

            con.Close();
            return count;
        }
    }
}