﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DatosDB;

namespace Capa2
{
    public class Conexionsql2
    {
        Conexionsql con = new Conexionsql();

        public int conSQL(string usuario, string contraseña)
        {
            return con.consultalogin(usuario, contraseña);
        }

        public int CrearUsuario(string Nombre1, string Nombre2, string Apellido1, string Apellido2, string Numerodoc, string Tipodoc, string Fechanacimiento, string Sexo, string Salario, string Numtelefono, string Direccion, string Usuario, string Contraseña)
        {
           return con.CrearUsuario(Nombre1, Nombre2, Apellido1, Apellido2, Numerodoc, Tipodoc, Fechanacimiento, Sexo, Salario, Numtelefono, Direccion, Usuario, Contraseña);
        }

        public int Modificar(string Id, string Nombre1, string Nombre2, string Apellido1, string Apellido2, string Numerodoc, string Tipodoc, string Fechanacimiento, string Sexo, string Salario, string Numtelefono, string Direccion, string Usuario, string Contraseña)
        {
            return con.Modificar(Id, Nombre1, Nombre2, Apellido1, Apellido2, Numerodoc, Tipodoc, Fechanacimiento, Sexo, Salario, Numtelefono, Direccion, Usuario, Contraseña);
        }
        public int ModificarCuenta(string Usuario, string Contraseña)
        {
            return con.ModificarCuenta(Usuario, Contraseña);
        }

        public int Eliminar(string Numerodoc)
        {
            return con.Eliminar(Numerodoc);
        }
        public Tuple<string, string, string, string, string, string, string> informacion(string Numerodoc) 
        {
            return con.informacion(Numerodoc);
        }

        public Tuple<string, string, string, string, string, string> informacion1(string Numerodoc)
        {
            return con.informacion1(Numerodoc);
        }

        public DataTable Pensum()
        {
            return con.Pensum();
        }

        public DataTable Ais()
        {
            return con.Ais();
        }

        public DataTable Es()
        {
            return con.Es();
        }

        public DataTable Ca()
        {
            return con.Ca();
        }

        public DataTable Or()
        {
            return con.Or();
        }

        public DataTable Cc10()
        {
            return con.Cc10();
        }

        public DataTable EduS()
        {
            return con.EduS();
        }

        public DataTable Me()
        {
            return con.Me();
        }
    }
}
