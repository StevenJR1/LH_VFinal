﻿namespace WindowsFormsApp1
{
    partial class btncrearUsuario
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(btncrearUsuario));
            this.txtNumTelefono = new System.Windows.Forms.TextBox();
            this.txtDireccion = new System.Windows.Forms.TextBox();
            this.txtPnombre = new System.Windows.Forms.TextBox();
            this.txtPApellido = new System.Windows.Forms.TextBox();
            this.txtNDoc = new System.Windows.Forms.TextBox();
            this.lbl11 = new System.Windows.Forms.Label();
            this.lbl10 = new System.Windows.Forms.Label();
            this.lbl9 = new System.Windows.Forms.Label();
            this.lbl8 = new System.Windows.Forms.Label();
            this.lbl7 = new System.Windows.Forms.Label();
            this.lbl6 = new System.Windows.Forms.Label();
            this.lbl5 = new System.Windows.Forms.Label();
            this.lbl4 = new System.Windows.Forms.Label();
            this.lbl3 = new System.Windows.Forms.Label();
            this.lbl1 = new System.Windows.Forms.Label();
            this.Btncrear = new System.Windows.Forms.Button();
            this.btncancelar = new System.Windows.Forms.Button();
            this.gbxidentificacion = new System.Windows.Forms.GroupBox();
            this.cbxtipoDoc = new System.Windows.Forms.ComboBox();
            this.gbxinformacionContacto = new System.Windows.Forms.GroupBox();
            this.gbxinformacionPersonal = new System.Windows.Forms.GroupBox();
            this.txtBxSApellido = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtBxSnombre = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.dtTmPckrFecha = new System.Windows.Forms.DateTimePicker();
            this.cmbBxSalario = new System.Windows.Forms.ComboBox();
            this.cmbBxSexo = new System.Windows.Forms.ComboBox();
            this.lblmensajePromo = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtUsuario = new System.Windows.Forms.TextBox();
            this.txtContraseña = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.tlTp = new System.Windows.Forms.ToolTip(this.components);
            this.gbxidentificacion.SuspendLayout();
            this.gbxinformacionContacto.SuspendLayout();
            this.gbxinformacionPersonal.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.SuspendLayout();
            // 
            // txtNumTelefono
            // 
            this.txtNumTelefono.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNumTelefono.ForeColor = System.Drawing.SystemColors.InfoText;
            this.txtNumTelefono.Location = new System.Drawing.Point(141, 40);
            this.txtNumTelefono.Name = "txtNumTelefono";
            this.txtNumTelefono.Size = new System.Drawing.Size(148, 21);
            this.txtNumTelefono.TabIndex = 1;
            // 
            // txtDireccion
            // 
            this.txtDireccion.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDireccion.ForeColor = System.Drawing.SystemColors.InfoText;
            this.txtDireccion.Location = new System.Drawing.Point(141, 99);
            this.txtDireccion.Name = "txtDireccion";
            this.txtDireccion.Size = new System.Drawing.Size(148, 21);
            this.txtDireccion.TabIndex = 3;
            // 
            // txtPnombre
            // 
            this.txtPnombre.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPnombre.ForeColor = System.Drawing.SystemColors.InfoText;
            this.txtPnombre.Location = new System.Drawing.Point(21, 59);
            this.txtPnombre.Name = "txtPnombre";
            this.txtPnombre.Size = new System.Drawing.Size(120, 21);
            this.txtPnombre.TabIndex = 1;
            // 
            // txtPApellido
            // 
            this.txtPApellido.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPApellido.ForeColor = System.Drawing.SystemColors.InfoText;
            this.txtPApellido.Location = new System.Drawing.Point(21, 123);
            this.txtPApellido.Name = "txtPApellido";
            this.txtPApellido.Size = new System.Drawing.Size(120, 21);
            this.txtPApellido.TabIndex = 5;
            // 
            // txtNDoc
            // 
            this.txtNDoc.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNDoc.ForeColor = System.Drawing.SystemColors.InfoText;
            this.txtNDoc.Location = new System.Drawing.Point(175, 38);
            this.txtNDoc.Name = "txtNDoc";
            this.txtNDoc.Size = new System.Drawing.Size(148, 21);
            this.txtNDoc.TabIndex = 2;
            // 
            // lbl11
            // 
            this.lbl11.AutoSize = true;
            this.lbl11.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.lbl11.Location = new System.Drawing.Point(15, 256);
            this.lbl11.Name = "lbl11";
            this.lbl11.Size = new System.Drawing.Size(126, 17);
            this.lbl11.TabIndex = 12;
            this.lbl11.Text = "Salario que devenga";
            // 
            // lbl10
            // 
            this.lbl10.AutoSize = true;
            this.lbl10.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.lbl10.Location = new System.Drawing.Point(18, 42);
            this.lbl10.Name = "lbl10";
            this.lbl10.Size = new System.Drawing.Size(94, 17);
            this.lbl10.TabIndex = 0;
            this.lbl10.Text = "N° de teléfono";
            // 
            // lbl9
            // 
            this.lbl9.AutoSize = true;
            this.lbl9.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.lbl9.Location = new System.Drawing.Point(18, 99);
            this.lbl9.Name = "lbl9";
            this.lbl9.Size = new System.Drawing.Size(65, 17);
            this.lbl9.TabIndex = 2;
            this.lbl9.Text = "Dirección";
            // 
            // lbl8
            // 
            this.lbl8.AutoSize = true;
            this.lbl8.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.lbl8.Location = new System.Drawing.Point(6, 38);
            this.lbl8.Name = "lbl8";
            this.lbl8.Size = new System.Drawing.Size(124, 17);
            this.lbl8.TabIndex = 0;
            this.lbl8.Text = "N° de identificación";
            // 
            // lbl7
            // 
            this.lbl7.AutoSize = true;
            this.lbl7.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.lbl7.Location = new System.Drawing.Point(6, 75);
            this.lbl7.Name = "lbl7";
            this.lbl7.Size = new System.Drawing.Size(123, 17);
            this.lbl7.TabIndex = 1;
            this.lbl7.Text = "Tipo de documento ";
            // 
            // lbl6
            // 
            this.lbl6.AutoSize = true;
            this.lbl6.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.lbl6.Location = new System.Drawing.Point(18, 219);
            this.lbl6.Name = "lbl6";
            this.lbl6.Size = new System.Drawing.Size(37, 17);
            this.lbl6.TabIndex = 10;
            this.lbl6.Text = "Sexo";
            // 
            // lbl5
            // 
            this.lbl5.AutoSize = true;
            this.lbl5.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.lbl5.Location = new System.Drawing.Point(18, 176);
            this.lbl5.Name = "lbl5";
            this.lbl5.Size = new System.Drawing.Size(133, 17);
            this.lbl5.TabIndex = 8;
            this.lbl5.Text = "Fecha de nacimiento ";
            // 
            // lbl4
            // 
            this.lbl4.AutoSize = true;
            this.lbl4.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.lbl4.Location = new System.Drawing.Point(21, 103);
            this.lbl4.Name = "lbl4";
            this.lbl4.Size = new System.Drawing.Size(96, 17);
            this.lbl4.TabIndex = 2;
            this.lbl4.Text = "Primer apellido";
            // 
            // lbl3
            // 
            this.lbl3.AutoSize = true;
            this.lbl3.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.lbl3.Location = new System.Drawing.Point(21, 32);
            this.lbl3.Name = "lbl3";
            this.lbl3.Size = new System.Drawing.Size(96, 17);
            this.lbl3.TabIndex = 0;
            this.lbl3.Text = "Primer nombre";
            // 
            // lbl1
            // 
            this.lbl1.AutoSize = true;
            this.lbl1.Font = new System.Drawing.Font("Times New Roman", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lbl1.Location = new System.Drawing.Point(252, -46);
            this.lbl1.Name = "lbl1";
            this.lbl1.Size = new System.Drawing.Size(161, 31);
            this.lbl1.TabIndex = 27;
            this.lbl1.Text = "Crear usuario";
            // 
            // Btncrear
            // 
            this.Btncrear.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.Btncrear.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btncrear.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btncrear.Location = new System.Drawing.Point(474, 516);
            this.Btncrear.Name = "Btncrear";
            this.Btncrear.Size = new System.Drawing.Size(134, 37);
            this.Btncrear.TabIndex = 5;
            this.Btncrear.Text = "Volver";
            this.Btncrear.UseVisualStyleBackColor = false;
            this.Btncrear.Click += new System.EventHandler(this.Btn2_Click);
            // 
            // btncancelar
            // 
            this.btncancelar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btncancelar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btncancelar.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncancelar.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btncancelar.Location = new System.Drawing.Point(628, 517);
            this.btncancelar.Name = "btncancelar";
            this.btncancelar.Size = new System.Drawing.Size(135, 36);
            this.btncancelar.TabIndex = 6;
            this.btncancelar.Text = "Crear Usuario";
            this.btncancelar.UseVisualStyleBackColor = false;
            this.btncancelar.Click += new System.EventHandler(this.btn1_Click);
            // 
            // gbxidentificacion
            // 
            this.gbxidentificacion.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.gbxidentificacion.Controls.Add(this.cbxtipoDoc);
            this.gbxidentificacion.Controls.Add(this.lbl7);
            this.gbxidentificacion.Controls.Add(this.lbl8);
            this.gbxidentificacion.Controls.Add(this.txtNDoc);
            this.gbxidentificacion.Location = new System.Drawing.Point(42, 111);
            this.gbxidentificacion.Name = "gbxidentificacion";
            this.gbxidentificacion.Size = new System.Drawing.Size(340, 120);
            this.gbxidentificacion.TabIndex = 1;
            this.gbxidentificacion.TabStop = false;
            this.gbxidentificacion.Text = "Identificación";
            // 
            // cbxtipoDoc
            // 
            this.cbxtipoDoc.FormattingEnabled = true;
            this.cbxtipoDoc.Items.AddRange(new object[] {
            "TARJETA IDENTIDAD",
            "CC",
            "CÉDULA DE EXTRANGERIA "});
            this.cbxtipoDoc.Location = new System.Drawing.Point(175, 75);
            this.cbxtipoDoc.Name = "cbxtipoDoc";
            this.cbxtipoDoc.Size = new System.Drawing.Size(148, 21);
            this.cbxtipoDoc.TabIndex = 3;
            // 
            // gbxinformacionContacto
            // 
            this.gbxinformacionContacto.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.gbxinformacionContacto.Controls.Add(this.lbl10);
            this.gbxinformacionContacto.Controls.Add(this.txtNumTelefono);
            this.gbxinformacionContacto.Controls.Add(this.txtDireccion);
            this.gbxinformacionContacto.Controls.Add(this.lbl9);
            this.gbxinformacionContacto.Location = new System.Drawing.Point(474, 111);
            this.gbxinformacionContacto.Name = "gbxinformacionContacto";
            this.gbxinformacionContacto.Size = new System.Drawing.Size(317, 145);
            this.gbxinformacionContacto.TabIndex = 3;
            this.gbxinformacionContacto.TabStop = false;
            this.gbxinformacionContacto.Text = "Información de contacto";
            // 
            // gbxinformacionPersonal
            // 
            this.gbxinformacionPersonal.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.gbxinformacionPersonal.Controls.Add(this.txtBxSApellido);
            this.gbxinformacionPersonal.Controls.Add(this.label4);
            this.gbxinformacionPersonal.Controls.Add(this.txtBxSnombre);
            this.gbxinformacionPersonal.Controls.Add(this.label3);
            this.gbxinformacionPersonal.Controls.Add(this.dtTmPckrFecha);
            this.gbxinformacionPersonal.Controls.Add(this.cmbBxSalario);
            this.gbxinformacionPersonal.Controls.Add(this.cmbBxSexo);
            this.gbxinformacionPersonal.Controls.Add(this.lbl5);
            this.gbxinformacionPersonal.Controls.Add(this.lbl6);
            this.gbxinformacionPersonal.Controls.Add(this.lbl11);
            this.gbxinformacionPersonal.Controls.Add(this.txtPApellido);
            this.gbxinformacionPersonal.Controls.Add(this.txtPnombre);
            this.gbxinformacionPersonal.Controls.Add(this.lbl3);
            this.gbxinformacionPersonal.Controls.Add(this.lbl4);
            this.gbxinformacionPersonal.Location = new System.Drawing.Point(43, 254);
            this.gbxinformacionPersonal.Name = "gbxinformacionPersonal";
            this.gbxinformacionPersonal.Size = new System.Drawing.Size(339, 299);
            this.gbxinformacionPersonal.TabIndex = 2;
            this.gbxinformacionPersonal.TabStop = false;
            this.gbxinformacionPersonal.Text = "Información personal";
            // 
            // txtBxSApellido
            // 
            this.txtBxSApellido.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBxSApellido.ForeColor = System.Drawing.SystemColors.InfoText;
            this.txtBxSApellido.Location = new System.Drawing.Point(164, 123);
            this.txtBxSApellido.Name = "txtBxSApellido";
            this.txtBxSApellido.Size = new System.Drawing.Size(120, 21);
            this.txtBxSApellido.TabIndex = 7;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.label4.Location = new System.Drawing.Point(164, 103);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(106, 17);
            this.label4.TabIndex = 6;
            this.label4.Text = "Segundo apellido";
            // 
            // txtBxSnombre
            // 
            this.txtBxSnombre.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBxSnombre.ForeColor = System.Drawing.SystemColors.InfoText;
            this.txtBxSnombre.Location = new System.Drawing.Point(167, 59);
            this.txtBxSnombre.Name = "txtBxSnombre";
            this.txtBxSnombre.Size = new System.Drawing.Size(120, 21);
            this.txtBxSnombre.TabIndex = 4;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.label3.Location = new System.Drawing.Point(164, 32);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(106, 17);
            this.label3.TabIndex = 3;
            this.label3.Text = "Segundo nombre";
            // 
            // dtTmPckrFecha
            // 
            this.dtTmPckrFecha.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtTmPckrFecha.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtTmPckrFecha.Location = new System.Drawing.Point(164, 173);
            this.dtTmPckrFecha.MaxDate = new System.DateTime(2022, 1, 1, 0, 0, 0, 0);
            this.dtTmPckrFecha.Name = "dtTmPckrFecha";
            this.dtTmPckrFecha.Size = new System.Drawing.Size(106, 21);
            this.dtTmPckrFecha.TabIndex = 9;
            this.dtTmPckrFecha.Value = new System.DateTime(2022, 1, 1, 0, 0, 0, 0);
            // 
            // cmbBxSalario
            // 
            this.cmbBxSalario.FormattingEnabled = true;
            this.cmbBxSalario.Items.AddRange(new object[] {
            "300000",
            "500000",
            "1000000",
            "2000000",
            "3000000",
            "4000000"});
            this.cmbBxSalario.Location = new System.Drawing.Point(164, 252);
            this.cmbBxSalario.Name = "cmbBxSalario";
            this.cmbBxSalario.Size = new System.Drawing.Size(148, 21);
            this.cmbBxSalario.TabIndex = 13;
            this.tlTp.SetToolTip(this.cmbBxSalario, "Escriba o seleccione el valor aproximado de su salario en COP\r\n");
            // 
            // cmbBxSexo
            // 
            this.cmbBxSexo.FormattingEnabled = true;
            this.cmbBxSexo.Items.AddRange(new object[] {
            "Femenino",
            "Masculino",
            "Otro"});
            this.cmbBxSexo.Location = new System.Drawing.Point(164, 219);
            this.cmbBxSexo.Name = "cmbBxSexo";
            this.cmbBxSexo.Size = new System.Drawing.Size(123, 21);
            this.cmbBxSexo.TabIndex = 11;
            // 
            // lblmensajePromo
            // 
            this.lblmensajePromo.AutoSize = true;
            this.lblmensajePromo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.lblmensajePromo.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblmensajePromo.Location = new System.Drawing.Point(271, 32);
            this.lblmensajePromo.Name = "lblmensajePromo";
            this.lblmensajePromo.Size = new System.Drawing.Size(286, 63);
            this.lblmensajePromo.TabIndex = 0;
            this.lblmensajePromo.Text = "Educación continua para ser un gran \r\nprofesional de la salud.\r\n\r\n";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.txtUsuario);
            this.groupBox1.Controls.Add(this.txtContraseña);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Location = new System.Drawing.Point(474, 313);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(317, 145);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Crear usuario";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.label1.Location = new System.Drawing.Point(18, 42);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(58, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "Usuario ";
            // 
            // txtUsuario
            // 
            this.txtUsuario.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtUsuario.ForeColor = System.Drawing.SystemColors.InfoText;
            this.txtUsuario.Location = new System.Drawing.Point(141, 40);
            this.txtUsuario.Name = "txtUsuario";
            this.txtUsuario.Size = new System.Drawing.Size(148, 21);
            this.txtUsuario.TabIndex = 1;
            // 
            // txtContraseña
            // 
            this.txtContraseña.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtContraseña.ForeColor = System.Drawing.SystemColors.InfoText;
            this.txtContraseña.Location = new System.Drawing.Point(141, 99);
            this.txtContraseña.Name = "txtContraseña";
            this.txtContraseña.Size = new System.Drawing.Size(148, 21);
            this.txtContraseña.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.label2.Location = new System.Drawing.Point(18, 99);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(75, 17);
            this.label2.TabIndex = 2;
            this.label2.Text = "Contraseña";
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // btncrearUsuario
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.RosyBrown;
            this.BackgroundImage = global::WindowsFormsApp1.Properties.Resources.Registro_2;
            this.ClientSize = new System.Drawing.Size(803, 570);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.lblmensajePromo);
            this.Controls.Add(this.gbxinformacionPersonal);
            this.Controls.Add(this.gbxinformacionContacto);
            this.Controls.Add(this.gbxidentificacion);
            this.Controls.Add(this.lbl1);
            this.Controls.Add(this.Btncrear);
            this.Controls.Add(this.btncancelar);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "btncrearUsuario";
            this.Text = "Registrar usuario";
            this.gbxidentificacion.ResumeLayout(false);
            this.gbxidentificacion.PerformLayout();
            this.gbxinformacionContacto.ResumeLayout(false);
            this.gbxinformacionContacto.PerformLayout();
            this.gbxinformacionPersonal.ResumeLayout(false);
            this.gbxinformacionPersonal.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox txtNumTelefono;
        private System.Windows.Forms.TextBox txtDireccion;
        private System.Windows.Forms.TextBox txtPnombre;
        private System.Windows.Forms.TextBox txtPApellido;
        private System.Windows.Forms.TextBox txtNDoc;
        private System.Windows.Forms.Label lbl11;
        private System.Windows.Forms.Label lbl10;
        private System.Windows.Forms.Label lbl9;
        private System.Windows.Forms.Label lbl8;
        private System.Windows.Forms.Label lbl7;
        private System.Windows.Forms.Label lbl6;
        private System.Windows.Forms.Label lbl5;
        private System.Windows.Forms.Label lbl4;
        private System.Windows.Forms.Label lbl3;
        private System.Windows.Forms.Label lbl1;
        private System.Windows.Forms.Button Btncrear;
        private System.Windows.Forms.Button btncancelar;
        private System.Windows.Forms.GroupBox gbxidentificacion;
        private System.Windows.Forms.GroupBox gbxinformacionContacto;
        private System.Windows.Forms.GroupBox gbxinformacionPersonal;
        private System.Windows.Forms.ComboBox cbxtipoDoc;
        private System.Windows.Forms.DateTimePicker dtTmPckrFecha;
        private System.Windows.Forms.ComboBox cmbBxSalario;
        private System.Windows.Forms.ComboBox cmbBxSexo;
        private System.Windows.Forms.Label lblmensajePromo;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtUsuario;
        private System.Windows.Forms.TextBox txtContraseña;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtBxSApellido;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtBxSnombre;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.ToolTip tlTp;
    }
}