﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace DatosDB
{
    public class Conexionsql
    {
        static string conexionstring = "Data Source=localhost;Initial Catalog=Usuario;Integrated Security=True";
        public SqlConnection conexion = new SqlConnection(conexionstring);

        public int consultalogin(string Usuario, string Contraseña)
        {
            int count;
            conexion.Open();
            string Query = "Select Count(*) From TBUsuario where Usuario ='" + Usuario + "'and contraseña ='" + Contraseña + "'";
            SqlCommand cmd = new SqlCommand(Query, conexion);
            count = Convert.ToInt32(cmd.ExecuteScalar());

            conexion.Close();
            return count;
        }

        public int CrearUsuario(string Nombre1, string Nombre2, string Apellido1, string Apellido2, string Numerodoc, string Tipodoc, string Fechanacimiento, string Sexo, string Salario, string Numtelefono, string Direccion, string Usuario, string Contraseña)
        {
            int flag = 0;
            conexion.Open();
            string query = "insert into TBUsuario values ('" + Nombre1 + "', '" + Nombre2 + "', '" + Apellido1 + "', '" + Apellido2 + "', '" + Numerodoc + "', '" + Tipodoc + "', '" + Fechanacimiento + "', '" + Sexo + "', '" + Salario + "', '" + Numtelefono + "', '" + Direccion + "', '" + Usuario + "', '" + Contraseña + "')";
            SqlCommand cmd = new SqlCommand(query, conexion);
            flag = cmd.ExecuteNonQuery();
            conexion.Close();
            return flag;
        }

        public int Modificar(string Id, string Nombre1, string Nombre2, string Apellido1, string Apellido2, string Numerodoc, string Tipodoc, string Fechanacimiento, string Sexo, string Salario, string Numtelefono, string Direccion, string Usuario, string Contraseña)
        {
            int flag = 0;
            conexion.Open();
            string query = "update TBUsuario set nombre1 = '" + Nombre1 + "', nombre2 = '" + Nombre2 + "', apellido1 = '" + Apellido1 + "', apellido2 = '" + Apellido2 + "', numerodoc = '" + Numerodoc + "', tipodoc = '" + Tipodoc + "', fechanacimiento = '" + Fechanacimiento + "', sexo = '" + Sexo + "', salario = '" + Salario + "', numtelefono = '" + Numtelefono + "', direccion = '" + Direccion + "', usuario = '" + Usuario + "', contraseña = '" + Contraseña + "' where id = '" + Id + "'";
            SqlCommand cmd = new SqlCommand(query, conexion);
            flag = cmd.ExecuteNonQuery();
            conexion.Close();
            return flag;
        }
        public int ModificarCuenta(string Usuario, string Contraseña)
        {
            int flag = 0;
            conexion.Open();
            string query = "update TBUsuario set contraseña = '" + Contraseña + "' where usuario = '" + Usuario + "'";
            SqlCommand cmd = new SqlCommand(query, conexion);
            flag = cmd.ExecuteNonQuery();
            conexion.Close();
            return flag;
        }

        public int Eliminar(string Numerodoc)
        {
            int flag = 0;
            conexion.Open();
            string query = "Delete from TBUsuario where Numerodoc = '" + Numerodoc + "'";
            SqlCommand cmd = new SqlCommand(query, conexion);
            flag = cmd.ExecuteNonQuery();
            conexion.Close();
            return flag;
        }
        public Tuple<string, string, string, string, string, string, string> informacion(string Numerodoc)
        {
            conexion.Open();

            string id = "NULL";
            string nombre1 = "NULL";
            string nombre2 = "NULL";
            string apellido1 = "NULL";
            string apellido2 = "NULL";
            string tipodoc = "NULL";
            string fechanac = "NULL";


            string query = "select * from TBUsuario where Numerodoc = '" + Numerodoc + "'";
            SqlCommand cmd = new SqlCommand(query, conexion);
            SqlDataReader info = cmd.ExecuteReader();

            if (info.Read())
            {
                id = info["Id"].ToString();
                nombre1 = info["Nombre1"].ToString();
                nombre2 = info["Nombre2"].ToString();
                apellido1 = info["Apellido1"].ToString();
                apellido2 = info["Apellido2"].ToString();
                tipodoc = info["Tipodoc"].ToString();
                fechanac = info["Fechanacimiento"].ToString();
            }

            conexion.Close();
            return Tuple.Create(id, nombre1, nombre2, apellido1, apellido2, tipodoc, fechanac);
        }

        public Tuple<string, string, string, string, string, string> informacion1(string Numerodoc)
        {
            conexion.Open();

            string usuario = "NULL";
            string contraseña = "NULL";
            string sexo = "NULL";
            string salario = "NULL";
            string numtelefono = "NULL";
            string direccion = "NULL";

            string query = "select * from TBUsuario where Numerodoc = '" + Numerodoc + "'";
            SqlCommand cmd = new SqlCommand(query, conexion);
            SqlDataReader info = cmd.ExecuteReader();

            if (info.Read())
            {
                sexo = info["Sexo"].ToString();
                salario = info["Salario"].ToString();
                numtelefono = info["Numtelefono"].ToString();
                direccion = info["Direccion"].ToString();
                usuario = info["Usuario"].ToString();
                contraseña = info["Contraseña"].ToString();

            }

            conexion.Close();
            return Tuple.Create(sexo, salario, numtelefono, direccion, usuario, contraseña);
        }

        public DataTable Pensum()
        {
            string query = "select * from TPensum";
            SqlCommand cmd = new SqlCommand(query, conexion);
            SqlDataAdapter data = new SqlDataAdapter(cmd);
            DataTable tabla = new DataTable();
            data.Fill(tabla);

            return tabla;
        }

        public DataTable Ais()
        {
            string query = "select * from T_AIS";
            SqlCommand cmd = new SqlCommand(query, conexion);
            SqlDataAdapter data = new SqlDataAdapter(cmd);
            DataTable tabla = new DataTable();
            data.Fill(tabla);

            return tabla;
        }

        public DataTable Es()
        {
            string query = "select * from T_ES";
            SqlCommand cmd = new SqlCommand(query, conexion);
            SqlDataAdapter data = new SqlDataAdapter(cmd);
            DataTable tabla = new DataTable();
            data.Fill(tabla);

            return tabla;
        }

        public DataTable Ca()
        {
            string query = "select * from T_CA";
            SqlCommand cmd = new SqlCommand(query, conexion);
            SqlDataAdapter data = new SqlDataAdapter(cmd);
            DataTable tabla = new DataTable();
            data.Fill(tabla);

            return tabla;
        }

        public DataTable Or()
        {
            string query = "select * from T_OR";
            SqlCommand cmd = new SqlCommand(query, conexion);
            SqlDataAdapter data = new SqlDataAdapter(cmd);
            DataTable tabla = new DataTable();
            data.Fill(tabla);

            return tabla;
        }

        public DataTable Cc10()
        {
            string query = "select * from T_CC10";
            SqlCommand cmd = new SqlCommand(query, conexion);
            SqlDataAdapter data = new SqlDataAdapter(cmd);
            DataTable tabla = new DataTable();
            data.Fill(tabla);

            return tabla;
        }

        public DataTable EduS()
        {
            string query = "select * from T_EduS";
            SqlCommand cmd = new SqlCommand(query, conexion);
            SqlDataAdapter data = new SqlDataAdapter(cmd);
            DataTable tabla = new DataTable();
            data.Fill(tabla);

            return tabla;
        }

        public DataTable Me()
        {
            string query = "select * from T_ME";
            SqlCommand cmd = new SqlCommand(query, conexion);
            SqlDataAdapter data = new SqlDataAdapter(cmd);
            DataTable tabla = new DataTable();
            data.Fill(tabla);

            return tabla;
        }
    }
}
