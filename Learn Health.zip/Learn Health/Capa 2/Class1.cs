﻿namespace Capa_2
{
    public class Class1
    {

    }
}